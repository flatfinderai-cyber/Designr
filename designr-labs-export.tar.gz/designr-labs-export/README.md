# DesignrLabs Export Package

This package contains the automation system and PRD for DesignrLabs.

## Contents

### 1. `automation/` folder
Complete Dev Tool Setup Automation System that uses Ralph Wiggum loops to automatically install and configure development tools.

**Key components:**
- `automation/workflows/` - Setup workflow templates
- `automation/scripts/` - Helper scripts for automation
- `automation/templates/` - Reusable workflow templates
- `automation/README.md` - System documentation
- `automation/HOW-TO-USE.md` - User guide
- `automation/AUTO-ACCEPT-SETUP.md` - Permission configuration guide

### 2. `DesignrLabs-prd.json`
Product Requirements Document with full specifications for the DesignrLabs platform.

## How to Use

### Option 1: Copy to New Repository
```bash
# Clone the new DesignrLabs repository
git clone https://github.com/flatfinderai-cyber/DesignrLabs.git
cd DesignrLabs

# Copy automation folder
cp -r /path/to/export/automation ./

# Copy PRD
cp /path/to/export/DesignrLabs-prd.json ./

# Commit
git add .
git commit -m "Add automation system and PRD"
git push
```

### Option 2: Initialize New Project
```bash
# Create new directory
mkdir DesignrLabs
cd DesignrLabs

# Initialize git
git init
git remote add origin https://github.com/flatfinderai-cyber/DesignrLabs.git

# Copy contents
cp -r /path/to/export/* ./

# Initial commit
git add .
git commit -m "Initial commit: automation system and PRD"
git push -u origin main
```

## Quick Start with Automation

After copying to your repository:

```bash
# Create a new workflow
./automation/quick-start.sh

# Follow prompts to create your setup workflow

# Start Ralph loop
./automation/start-ralph.sh <workflow-name>
```

## DesignrLabs PRD Highlights

- **Product**: AI-powered sketch-to-code platform
- **Tech Stack**: Next.js 14+, TypeScript, Tailwind, Supabase
- **AI Services**: GPT-4 Vision, Claude 3.5 Sonnet
- **MVP Features**: Sketch upload, AI detection, live UI rendering, code export
- **Ralph Loop**: Autonomous development with 25 max iterations

See `DesignrLabs-prd.json` for complete specifications.

## Next Steps

1. Copy these files to your DesignrLabs repository
2. Set up Next.js 14 + TypeScript project
3. Configure Supabase (auth, database, storage)
4. Create @specs/ directory per PRD
5. Implement .claude/ralph-loop.local.md
6. Start building features F001-F010

## Support

For automation system help, see `automation/HOW-TO-USE.md`
For DesignrLabs specs, see `DesignrLabs-prd.json`
